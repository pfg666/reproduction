#!/bin/bash
readonly SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
readonly DTLS_FUZZER_JAR=$SCRIPT_DIR/"dtls-fuzzer.jar"
readonly DTLS_FUZZER_ARGS=$SCRIPT_DIR/"dtls-fuzzer.args"

readonly PORT=20000

gnutls_pid=""

# launches gnutls in a separate process
function launch_gnutls() {
    echo "Launching gnutls in a separate process running: "
    echo $MBEDTLS_DIR/programs/ssl/ssl_server2 dtls=1 psk=1234 mtu=5000 server_port=$PORT exchanges=100 hs_timeout=20000-120000
    gnutls-serv  --udp --x509keyfile $SCRIPT_DIR/rsa2048_key.pem --x509certfile $SCRIPT_DIR/rsa2048_cert.pem --x509cafile $SCRIPT_DIR/rsa2048_cert.pem --pskpasswd $SCRIPT_DIR/keys.psk --require-client-cert --priority NORMAL:+PSK:+SRP --mtu 1500 -p $PORT &
    gnutls_pid=$!
}

setup_gnutls

launch_gnutls
sleep 1

echo "Executing invalid message sequence $gnutls_pid"
java -Dgnutls.version=3.7.1 -jar $DTLS_FUZZER_JAR $DTLS_FUZZER_ARGS -test $1

kill $gnutls_pid

