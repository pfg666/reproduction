readonly SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"

readonly JDK_17_ARCH_URL="https://download.java.net/java/early_access/jdk17/23/GPL/openjdk-17-ea+23_linux-x64_bin.tar.gz"
readonly JDK_17_DIR="$SCRIPT_DIR/jdk-17-EA"

readonly JSSE_PROGRAM_DIR="$SCRIPT_DIR/jsse-dtls-clientserver"
readonly JSSE_PROGRAM_ARCH_URL="https://github.com/assist-project/jsse-dtls-clientserver/archive/refs/tags/v1.0.0.tar.gz"

readonly PORT=20000

# downloads and unpacks and archive
function solve_arch() {
    arch_url=$1
    target_dir=$2
    temp_dir=/tmp/`(basename $arch_url)`
    echo $temp_dir
    echo "Fetching/unpacking from $arch_url into $target_dir"
    if [[ ! -f "$temp_dir" ]]
    then
        echo "Downloading archive from url to $temp_dir"
        wget -nc --no-check-certificate $arch_url -O $temp_dir
    fi
    
    mkdir $target_dir
    # ${temp_dir##*.} retrieves the substring between the last index of . and the end of $temp_dir
    arch=`echo "${temp_dir##*.}"`
    if [[ $arch == "xz" ]]
    then
        tar_param="-xJf"
    else 
        tar_param="zxvf"
    fi
    echo $tar_param
    if [ $target_dir ] ; then
        tar $tar_param $temp_dir -C $target_dir --strip-components=1
    else 
        tar $tar_param $temp_dir
    fi
}

function setup_jsse_program() {
    if [[ ! -d $JDK_17_DIR ]]
    then 
        solve_arch $JDK_17_ARCH_URL $JDK_17_DIR 
    fi

    if [[ ! -d $JSSE_PROGRAM_DIR ]]
    then 
        solve_arch $JSSE_PROGRAM_ARCH_URL $JSSE_PROGRAM_DIR
        (cd $JSSE_PROGRAM_DIR; JAVA_HOME=$JDK_17_DIR mvn install assembly:single; cp target/jsse-dtls-clientserver.jar $SCRIPT_DIR/jsse-dtls-clientserver.jar)
    fi
}

if [[ ! $# -eq  1 ]]
then
    echo "Usage:"
    echo "reproduce.sh scenario_file"
    exit 1
fi


# sets up the JDK and the test program
setup_jsse_program

# execute invalid sequence of inputs using DTLS-Fuzzer
( java -Djsse.version=17-EA -jar $SCRIPT_DIR/dtls-fuzzer.jar $SCRIPT_DIR/dtls-fuzzer.args -test $1 -showTransitionSequence ) &
fuzzer_pid=$!

sleep 3

# launch JSSE program
( $JDK_17_DIR/bin/java -jar $SCRIPT_DIR/jsse-dtls-clientserver.jar -client -port 20000 -hostname localhost -runWait 1000 -keyLocation $SCRIPT_DIR/rsa2048.jks -trustLocation $SCRIPT_DIR/rsa2048.jks -operation BASIC ) &
sut_pid=$!

wait $fuzzer_pid
kill $sut_pid

#bash $SCRIPT_DIR/stop_process_at_port.sh 20000
